# P1-Image-Classification-by-Machine-Learning-AICTE-Internship

I have done this project to classify images by using CNNmodel and Pre Trained Mobile Net model. I created the streamlit app for the same.


## How to rum the code



### Ack
